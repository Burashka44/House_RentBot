import asyncio
import logging
import sys

from aiogram import Bot, Dispatcher
from aiogram.enums import ParseMode
from aiogram.client.default import DefaultBotProperties

from bot.config import config
from bot.handlers import common, admin, tenant, support
from bot.middlewares.consent import ConsentMiddleware

from bot.services.notification_service import setup_notifications
from bot.cron import scheduler_loop



async def main():
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(name)s - %(message)s",
        stream=sys.stdout,
    )

    bot = Bot(
        token=config.BOT_TOKEN, 
        default=DefaultBotProperties(parse_mode=ParseMode.HTML)
    )
    dp = Dispatcher()
    
    # Setup Services
    setup_notifications(bot)

    # Middleware registration
    dp.update.middleware(ConsentMiddleware())

    # Router registration - ORDER MATTERS!
    # Admin first - AdminFilter passes admins to admin handlers
    # Non-admins skip admin router and go to common/tenant
    dp.include_router(admin.router)
    dp.include_router(common.router)
    dp.include_router(tenant.router)
    dp.include_router(support.router)

    # Load admins from DB
    from bot.database.core import AsyncSessionLocal
    from bot.services.user_service import get_all_admins
    
    try:
        async with AsyncSessionLocal() as session:
            db_admins = await get_all_admins(session)
            count = 0
            for u in db_admins:
                if u.role == 'owner':
                     if u.tg_id not in config.OWNER_IDS:
                          config.OWNER_IDS.append(u.tg_id)
                # Add all to ADMIN_IDS (owners are admins too)
                if u.tg_id not in config.ADMIN_IDS:
                     config.ADMIN_IDS.append(u.tg_id)
                count += 1
            logging.info(f"Loaded {count} admins from DB.")
    except Exception as e:
        logging.error(f"Failed to load admins from DB: {e}")

    # Start Scheduler
    asyncio.create_task(scheduler_loop())

    logging.info("Starting bot...")
    await dp.start_polling(bot)

if __name__ == "__main__":
    try:
        if sys.platform == "win32":
            asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        logging.info("Bot stopped.")
